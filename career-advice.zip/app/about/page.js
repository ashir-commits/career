export const metadata = {
  title: 'About | Career Advice',
  description:
    'Learn more about Career Advice, our mission to empower professionals, and our evidence-based coaching approach.',
};

export default function AboutPage() {
  return (
    <main className="max-w-5xl mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-6">About Career Advice</h1>
      <p className="mb-4">
        Career Advice is a London‑based consultancy dedicated to helping professionals navigate and thrive in
        their careers across diverse industries. Our evidence‑based programmes combine data‑driven insights,
        industry expertise and personalized coaching to help you land roles, accelerate promotions and make
        successful pivots.
      </p>
      <p className="mb-4">
        Our advisors bring decades of experience from sectors including consumer goods, finance, healthcare,
        digital technology and the public sector. We share practical strategies for crafting standout CVs,
        preparing for interviews, building networks and negotiating offers — all tailored to your goals.
      </p>
      <p className="mb-4">
        Whether you’re just starting out, looking to step up to the next level or aiming to switch
        industries, Career Advice provides the guidance and support you need to achieve lasting success.
      </p>
      <p>
        We are located at <strong>124 City Road, London, England, EC1V 2NX</strong> and serve clients globally
        through virtual consultations.
      </p>
    </main>
  );
}