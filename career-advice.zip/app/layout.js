import './globals.css';

export const metadata = {
  title: 'Career Advice — Evidence-based Career Coaching',
  description: 'Career Advice helps professionals land roles and promotions with data-driven coaching, ATS-optimized CVs, interview prep, and negotiation support.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-primary text-dark">
        <header className="sticky top-0 z-50 bg-primary/95 backdrop-blur border-b border-gray-200">
          <nav className="max-w-7xl mx-auto flex items-center justify-between px-4 py-3">
            <div className="text-xl font-bold tracking-tight">Career Advice</div>
            <div className="hidden md:flex items-center gap-6">
              <a href="/" className="hover:text-accent">Home</a>
              <a href="/services" className="hover:text-accent">Services</a>
              <a href="/about" className="hover:text-accent">About</a>
            </div>
            <div className="flex items-center">
              <a href="/#contact" className="px-4 py-2 bg-accent text-dark rounded-md shadow hover:shadow-lg transition">Book a Consult</a>
            </div>
          </nav>
        </header>
        {children}
      </body>
    </html>
  );
}