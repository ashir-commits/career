'use client';

export const metadata = {
  title: 'Services | Career Advice',
  description:
    'Sector-specific career advisory for Consumer Goods, Digital Economy, Energy, Financial Services, Government & Public Sector, Healthcare & NHS, Manufacturing, Media & Entertainment, Pharmaceuticals & Medical and Tender Writing.',
};

const services = [
  {
    title: 'Consumer Goods',
    description:
      'Break into roles in retail, FMCG and supply chain management with coaching tailored to consumer goods companies. We help optimize your CV, prepare for sector-specific interviews and build negotiating skills for offers.',
  },
  {
    title: 'Digital Economy',
    description:
      'Prepare for positions in tech, e-commerce and digital start‑ups with our digital economy program. We guide you through portfolio building, technical interview prep, and networking in the fast-paced digital landscape.',
  },
  {
    title: 'Energy',
    description:
      'Transition into renewable energy and utilities with industry-specific guidance for a sustainable future. Our advisors help you articulate your passion for clean tech and navigate the evolving energy job market.',
  },
  {
    title: 'Financial Services',
    description:
      'Elevate your career in banking, investment and risk management. We offer tailored coaching for CV refinement, competency interviews, case studies and negotiations in the competitive financial sector.',
  },
  {
    title: 'Government & Public Sector',
    description:
      'Explore opportunities in the civil service, local and national government, NGOs and multilateral organisations. From application forms to panel interviews, we help you present your commitment to public service.',
  },
  {
    title: 'Healthcare & NHS',
    description:
      'Navigate careers in hospitals, public health and the NHS. We support clinical and non‑clinical candidates with personal statements, interview simulations and strategies for landing roles across healthcare settings.',
  },
  {
    title: 'Manufacturing',
    description:
      'Step into production operations, supply chain and engineering roles with confidence. Our programme emphasizes lean practices, problem solving and the communication skills valued in modern manufacturing.',
  },
  {
    title: 'Media & Entertainment',
    description:
      'Enter film, TV, music and digital content careers with a competitive edge. We assist with portfolio review, audition preparation and networking tactics unique to creative industries.',
  },
  {
    title: 'Pharmaceuticals & Medical',
    description:
      'Pursue opportunities in pharma research, clinical trials, regulatory affairs and medical communications. We provide tailored advice on presenting technical expertise and collaborating across cross-functional teams.',
  },
  {
    title: 'Tender Writing',
    description:
      'Specialised coaching to craft winning bids and proposals. We help professionals structure compelling tenders, align with procurement criteria and highlight value propositions to secure contracts.',
  },
];

export default function ServicesPage() {
  return (
    <main className="max-w-7xl mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8">Our Services</h1>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((service) => (
          <div key={service.title} className="p-6 rounded-md bg-white shadow-md hover:shadow-lg transition">
            <h2 className="text-xl font-semibold mb-2">{service.title}</h2>
            <p className="text-sm text-gray-700">{service.description}</p>
          </div>
        ))}
      </div>
    </main>
  );
}