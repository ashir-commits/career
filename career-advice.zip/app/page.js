'use client';
import { useEffect } from 'react';

export default function Home() {
  // Ensure scrolling to anchor on mount if there is a hash
  useEffect(() => {
    const hash = window.location.hash;
    if (hash) {
      const el = document.getElementById(hash.slice(1));
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, []);

  return (
    <main>
      {/* Hero Section with background and video */}
      <section className="relative flex flex-col md:flex-row items-center justify-center min-h-[80vh] overflow-hidden">
        {/* Background image */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('/london.png')" }}
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black/60" />
        {/* Content */}
        <div className="relative z-10 flex flex-col md:flex-row w-full max-w-7xl mx-auto p-6 gap-8">
          <div className="flex-1 flex flex-col justify-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold">Career Advice</h1>
            <p className="mt-4 text-lg md:text-xl max-w-md">
              Evidence-based career coaching for professionals looking to thrive.
            </p>
            <a
              href="/#contact"
              className="mt-8 inline-block px-6 py-3 bg-accent text-dark font-semibold rounded-md shadow hover:shadow-lg transition"
            >
              Book a Consult
            </a>
          </div>
          <div className="flex-1">
            <video
              className="w-full h-[300px] md:h-[400px] object-cover rounded-md shadow-lg"
              autoPlay
              muted
              loop
              playsInline
              poster="/image.webp"
            >
              {/* HIGHLIGHT: new video source added here */}
              <source src="/CAREER%20ADVICE.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          </div>
        </div>
      </section>

      {/* Services preview */}
      <section className="py-16 bg-primary text-dark">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold mb-6">Our Services</h2>
          <p className="mb-6 max-w-3xl">
            We provide sector-specific career advisory across a range of industries. Explore our{' '}
            <a href="/services" className="text-accent underline hover:opacity-80">Services</a> page to learn more.
          </p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div className="p-4 rounded-md bg-white shadow">
              <h3 className="font-semibold text-lg mb-2">Consumer Goods</h3>
              <p className="text-sm text-gray-700">
                Break into roles in retail, FMCG and supply chain management with coaching tailored to consumer goods companies.
              </p>
            </div>
            <div className="p-4 rounded-md bg-white shadow">
              <h3 className="font-semibold text-lg mb-2">Digital Economy</h3>
              <p className="text-sm text-gray-700">
                Prepare for positions in tech, e-commerce, and digital start-ups with our digital economy program.
              </p>
            </div>
            <div className="p-4 rounded-md bg-white shadow">
              <h3 className="font-semibold text-lg mb-2">Energy</h3>
              <p className="text-sm text-gray-700">
                Transition into renewable energy and utilities with industry-specific guidance for a sustainable future.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-white text-dark">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold mb-6">Contact Us</h2>
          <p className="mb-4">Tell us about your career goals and we’ll be in touch soon.</p>
          <form
            className="space-y-4"
            action="mailto:waleedsaeed354@gmail.com"
            method="post"
            encType="text/plain"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                name="Name"
                required
                placeholder="Your name"
                className="p-3 border rounded-md w-full"
              />
              <input
                type="email"
                name="Email"
                required
                placeholder="you@example.com"
                className="p-3 border rounded-md w-full"
              />
            </div>
            <input
              type="text"
              name="Phone"
              placeholder="Phone (optional)"
              className="p-3 border rounded-md w-full"
            />
            <textarea
              name="Message"
              required
              placeholder="Tell us about your goals"
              className="p-3 border rounded-md w-full h-32"
            />
            <button
              type="submit"
              className="px-6 py-3 bg-accent text-dark font-semibold rounded-md shadow hover:shadow-lg transition"
            >
              Send
            </button>
          </form>
          <div className="mt-8">
            <p className="font-semibold">Address:</p>
            <p>124 City Road, London, England, EC1V 2NX</p>
          </div>
        </div>
      </section>
    </main>
  );
}