/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        primary: "#F5F5F4", // ivory
        accent: "#D8C3A5", // warm taupe
        dark: "#373737",   // charcoal
      }
    }
  },
  plugins: [],
}